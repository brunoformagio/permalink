// =================================
// GENERATIVE ART TEMPLATE
// =================================

// Deterministic random number generator (same as working example)
class Random {
    constructor(seed) {
        this.seed = seed;
    }
    
    next() {
        this.seed = (this.seed * 1664525 + 1013904223) % 4294967296;
        return this.seed / 4294967296;
    }
    
    range(min, max) {
        return min + this.next() * (max - min);
    }
    
    int(min, max) {
        return Math.floor(this.range(min, max + 1));
    }
    
    choice(array) {
        return array[this.int(0, array.length - 1)];
    }
}

// Global variables
let canvas, ctx, rng;
let currentHash = '';
let isNFTMode = false;
let animationId;
let isAnimating = true;
let time = 0;

// Initialize on page load
window.onload = function() {
    canvas = document.getElementById('canvas');
    ctx = canvas.getContext('2d');
    
    // Set canvas to full screen
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // Get hash from multiple sources (same logic as working example)
    let hashParam = null;
    
    // Method 1: Check if hash was injected globally by Permalink platform
    if (window.PERMALINK_TOKEN_HASH) {
        hashParam = window.PERMALINK_TOKEN_HASH;
        isNFTMode = window.PERMALINK_IS_NFT_MODE || true;
    }
    
    // Method 2: Try URL parameters
    if (!hashParam) {
        const urlParams = new URLSearchParams(window.location.search);
        hashParam = urlParams.get('hash');
    }
    
    // Validate and use the hash
    if (hashParam && hashParam.startsWith('0x') && hashParam.length > 10) {
        // This looks like a real blockchain hash - NFT mode
        currentHash = hashParam;
        isNFTMode = true;
        console.log('🎨 NFT Mode - Using hash:', currentHash.substring(0, 10) + '...');
    } else {
        // Testing/preview mode
        currentHash = generateRandomHash();
        isNFTMode = false;
        console.log('🎨 Preview Mode - Generated hash:', currentHash.substring(0, 10) + '...');
    }
    
    // Listen for hash messages (for platform integration)
    window.addEventListener('message', function(event) {
        if (event.data && event.data.type === 'SET_HASH') {
            console.log('🎨 Received SET_HASH message:', event.data.hash.substring(0, 10) + '...');
            currentHash = event.data.hash;
            isNFTMode = event.data.isNFTMode || true;
            generate();
        }
    });
    
    generate();
    animate();
};

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    console.log('🎨 Canvas resized to:', canvas.width, 'x', canvas.height);
    if (ctx) { // Only regenerate if already initialized
        generate();
    }
}

function generateRandomHash() {
    const chars = '0123456789abcdef';
    let hash = '0x';
    for (let i = 0; i < 64; i++) {
        hash += chars[Math.floor(Math.random() * chars.length)];
    }
    return hash;
}

function hashToSeed(hash) {
    let seed = 0;
    for (let i = 0; i < hash.length; i++) {
        seed = ((seed << 5) - seed + hash.charCodeAt(i)) & 0xffffffff;
    }
    return Math.abs(seed);
}

function generate() {
    // Initialize random generator with hash (same logic as working example)
    const seed = hashToSeed(currentHash);
    rng = new Random(seed);
    
    console.log('🎨 Generating art with hash:', currentHash.substring(0, 10) + '...');
    
    // =================================
    // YOUR ART GENERATION CODE HERE
    // =================================
    // Replace this section with your own artwork logic
    
    // Clear canvas with black background
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Generate artwork properties based on hash
    const backgroundColor = rng.choice(['#001a2e', '#2e1a00', '#1a002e', '#002e1a']);
    const shapeCount = rng.int(30, 150);
    const colorScheme = rng.choice(['warm', 'cool', 'neon']);
    const pattern = rng.choice(['circles', 'squares', 'triangles']);
    
    console.log('🎨 Art properties:', { backgroundColor, shapeCount, colorScheme, pattern });
    
    // Set background
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Add gradient effect
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, Math.max(canvas.width, canvas.height));
    gradient.addColorStop(0, 'rgba(255,255,255,0.1)');
    gradient.addColorStop(1, 'rgba(0,0,0,0.3)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Generate shapes
    for (let i = 0; i < shapeCount; i++) {
        const x = rng.range(0, canvas.width);
        const y = rng.range(0, canvas.height);
        const size = rng.range(Math.min(canvas.width, canvas.height) * 0.005, Math.min(canvas.width, canvas.height) * 0.08);
        
        // Color based on scheme
        let color;
        switch (colorScheme) {
            case 'warm':
                color = `hsl(${rng.range(0, 60)}, ${rng.range(70, 100)}%, ${rng.range(50, 85)}%)`;
                break;
            case 'cool':
                color = `hsl(${rng.range(180, 280)}, ${rng.range(70, 100)}%, ${rng.range(50, 85)}%)`;
                break;
            case 'neon':
                color = `hsl(${rng.range(0, 360)}, ${rng.range(80, 100)}%, ${rng.range(65, 95)}%)`;
                break;
            default:
                color = `hsl(0, 0%, ${rng.range(40, 90)}%)`;
        }
        
        ctx.fillStyle = color;
        ctx.globalAlpha = rng.range(0.5, 0.95);
        
        // Add glow effect occasionally
        if (rng.next() < 0.3) {
            ctx.shadowColor = color;
            ctx.shadowBlur = size * 0.5;
        } else {
            ctx.shadowBlur = 0;
        }
        
        // Draw shape based on pattern
        switch (pattern) {
            case 'circles':
                ctx.beginPath();
                ctx.arc(x, y, size, 0, Math.PI * 2);
                ctx.fill();
                break;
            case 'squares':
                ctx.save();
                ctx.translate(x, y);
                ctx.rotate(rng.range(0, Math.PI * 2));
                ctx.fillRect(-size/2, -size/2, size, size);
                ctx.restore();
                break;
            case 'triangles':
                ctx.beginPath();
                ctx.moveTo(x, y - size);
                ctx.lineTo(x - size * 0.866, y + size * 0.5);
                ctx.lineTo(x + size * 0.866, y + size * 0.5);
                ctx.closePath();
                ctx.fill();
                break;
        }
        
        ctx.shadowBlur = 0; // Reset shadow
    }
    
    ctx.globalAlpha = 1;
    console.log('🎨 Art generation complete!');
}

// Simple animation loop (optional - remove if you want static art)
function animate() {
    if (!isAnimating) return;
    
    time += 0.01;
    
    // You can add animation here if desired
    // For static art, just call generate() once and remove this function
    
    animationId = requestAnimationFrame(animate);
}

// =================================
// TEMPLATE INSTRUCTIONS
// =================================
/*

HOW TO USE THIS TEMPLATE:

1. Replace the artwork generation code in the generate() function with your own logic
2. Use the 'rng' object for all randomization to ensure deterministic results
3. Available rng methods:
   - rng.next()           // Returns 0-1
   - rng.range(min, max)  // Returns float between min-max
   - rng.int(min, max)    // Returns integer between min-max
   - rng.choice(array)    // Returns random element from array

4. The canvas automatically fills the entire viewport
5. Scale your artwork elements relative to canvas size for responsiveness
6. Test with different hashes to ensure variety

IMPORTANT:
- Always use the rng object for randomization, never Math.random()
- The same hash should always produce the same artwork
- Canvas automatically resizes with viewport
- Keep total file size under 16KB for on-chain storage
- Package as: index.html + sketch.js in a .zip file
- Remove the animate() function if you want static artwork

EXAMPLE USAGE:
// Your artwork generation
const nodeCount = rng.int(5, 15);
const mainColor = rng.choice(['red', 'blue', 'green']);
const x = rng.range(0, canvas.width);
const y = rng.range(0, canvas.height);

*/ 